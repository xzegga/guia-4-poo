package pclases;

import javax.swing.JOptionPane;

public class Algebra {

    public Algebra() {
        JOptionPane.showMessageDialog(null, "La operación a realizar es suma");
    }
    
}
