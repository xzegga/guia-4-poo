package pclases;


public class Operaciones {
    public int multiplicar(int num1, int num2) {
        return num1 * num2;
    }

    public double multiplicar(double num1, double num2, double num3) {
        return num1 * num2 * num3;
    }

    public int sumar(int num1, int num2, int num3) {
        return num1 + num2 + num3;
    }

    public double sumar(double num1, double num2, double num3) {
        return num1 + num2 + num3;
    }
}
